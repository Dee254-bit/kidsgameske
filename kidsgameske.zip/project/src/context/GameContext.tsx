import React, { createContext, useContext, useReducer, ReactNode } from 'react';

export interface Game {
  id: string;
  title: string;
  description: string;
  category: 'problem-solving' | 'memory' | 'math' | 'reading' | 'motor-skills' | 'creative';
  difficulty: 'easy' | 'medium' | 'hard';
  levels: number;
  currentLevel: number;
  completed: boolean;
  stars: number;
  icon: string;
  color: string;
  component: string;
}

export interface GameState {
  games: Game[];
  currentGame: Game | null;
  userProgress: Record<string, { level: number; stars: number; completed: boolean }>;
  adminMode: boolean;
}

type GameAction = 
  | { type: 'SET_CURRENT_GAME'; payload: Game }
  | { type: 'UPDATE_PROGRESS'; payload: { gameId: string; level: number; stars: number } }
  | { type: 'TOGGLE_ADMIN_MODE' }
  | { type: 'ADD_GAME'; payload: Game }
  | { type: 'UPDATE_GAME'; payload: Game }
  | { type: 'DELETE_GAME'; payload: string };

const initialGames: Game[] = [
  {
    id: 'memory-match',
    title: 'Memory Match',
    description: 'Match pairs of colorful cards to improve your memory!',
    category: 'memory',
    difficulty: 'easy',
    levels: 5,
    currentLevel: 1,
    completed: false,
    stars: 0,
    icon: '🧠',
    color: 'bg-gradient-to-br from-pink-400 to-purple-500',
    component: 'MemoryMatch'
  },
  {
    id: 'math-adventure',
    title: 'Math Adventure',
    description: 'Solve fun math problems and collect treasures!',
    category: 'math',
    difficulty: 'easy',
    levels: 8,
    currentLevel: 1,
    completed: false,
    stars: 0,
    icon: '🔢',
    color: 'bg-gradient-to-br from-green-400 to-blue-500',
    component: 'MathAdventure'
  },
  {
    id: 'word-builder',
    title: 'Word Builder',
    description: 'Build words from letters and expand your vocabulary!',
    category: 'reading',
    difficulty: 'easy',
    levels: 6,
    currentLevel: 1,
    completed: false,
    stars: 0,
    icon: '📝',
    color: 'bg-gradient-to-br from-yellow-400 to-orange-500',
    component: 'WordBuilder'
  },
  {
    id: 'color-mixer',
    title: 'Color Mixer',
    description: 'Mix colors and create beautiful artworks!',
    category: 'creative',
    difficulty: 'easy',
    levels: 4,
    currentLevel: 1,
    completed: false,
    stars: 0,
    icon: '🎨',
    color: 'bg-gradient-to-br from-red-400 to-pink-500',
    component: 'ColorMixer'
  },
  {
    id: 'shape-sorter',
    title: 'Shape Sorter',
    description: 'Sort shapes into the right containers!',
    category: 'problem-solving',
    difficulty: 'easy',
    levels: 7,
    currentLevel: 1,
    completed: false,
    stars: 0,
    icon: '🔷',
    color: 'bg-gradient-to-br from-indigo-400 to-purple-500',
    component: 'ShapeSorter'
  },
  {
    id: 'number-counter',
    title: 'Number Counter',
    description: 'Count objects and learn numbers!',
    category: 'math',
    difficulty: 'easy',
    levels: 5,
    currentLevel: 1,
    completed: false,
    stars: 0,
    icon: '🔢',
    color: 'bg-gradient-to-br from-teal-400 to-cyan-500',
    component: 'NumberCounter'
  },
  {
    id: 'pattern-puzzle',
    title: 'Pattern Puzzle',
    description: 'Complete patterns and boost your logic skills!',
    category: 'problem-solving',
    difficulty: 'medium',
    levels: 6,
    currentLevel: 1,
    completed: false,
    stars: 0,
    icon: '🧩',
    color: 'bg-gradient-to-br from-purple-400 to-pink-500',
    component: 'PatternPuzzle'
  },
  {
    id: 'animal-sounds',
    title: 'Animal Sounds',
    description: 'Match animals with their sounds!',
    category: 'memory',
    difficulty: 'easy',
    levels: 4,
    currentLevel: 1,
    completed: false,
    stars: 0,
    icon: '🐾',
    color: 'bg-gradient-to-br from-green-400 to-teal-500',
    component: 'AnimalSounds'
  },
  // New games from "Coming Soon" section
  {
    id: 'puzzle-master',
    title: 'Puzzle Master',
    description: 'Solve challenging puzzles and become a master!',
    category: 'problem-solving',
    difficulty: 'medium',
    levels: 8,
    currentLevel: 1,
    completed: false,
    stars: 0,
    icon: '🧩',
    color: 'bg-gradient-to-br from-purple-400 to-indigo-500',
    component: 'PuzzleMaster'
  },
  {
    id: 'space-explorer',
    title: 'Space Explorer',
    description: 'Explore the galaxy and learn about planets and stars!',
    category: 'creative',
    difficulty: 'medium',
    levels: 10,
    currentLevel: 1,
    completed: false,
    stars: 0,
    icon: '🚀',
    color: 'bg-gradient-to-br from-blue-500 to-purple-600',
    component: 'SpaceExplorer'
  },
  {
    id: 'garden-helper',
    title: 'Garden Helper',
    description: 'Plant seeds, water flowers, and grow a beautiful garden!',
    category: 'creative',
    difficulty: 'easy',
    levels: 6,
    currentLevel: 1,
    completed: false,
    stars: 0,
    icon: '🌱',
    color: 'bg-gradient-to-br from-green-400 to-emerald-500',
    component: 'GardenHelper'
  },
  {
    id: 'music-maker',
    title: 'Music Maker',
    description: 'Create beautiful melodies and learn about music!',
    category: 'creative',
    difficulty: 'easy',
    levels: 7,
    currentLevel: 1,
    completed: false,
    stars: 0,
    icon: '🎵',
    color: 'bg-gradient-to-br from-pink-400 to-rose-500',
    component: 'MusicMaker'
  },
  {
    id: 'chef-challenge',
    title: 'Chef Challenge',
    description: 'Cook delicious meals and learn about healthy eating!',
    category: 'creative',
    difficulty: 'medium',
    levels: 9,
    currentLevel: 1,
    completed: false,
    stars: 0,
    icon: '👨‍🍳',
    color: 'bg-gradient-to-br from-orange-400 to-red-500',
    component: 'ChefChallenge'
  },
  {
    id: 'treasure-hunt',
    title: 'Treasure Hunt',
    description: 'Follow clues and find hidden treasures on exciting adventures!',
    category: 'problem-solving',
    difficulty: 'medium',
    levels: 12,
    currentLevel: 1,
    completed: false,
    stars: 0,
    icon: '🏴‍☠️',
    color: 'bg-gradient-to-br from-amber-500 to-orange-600',
    component: 'TreasureHunt'
  },
  {
    id: 'time-traveler',
    title: 'Time Traveler',
    description: 'Travel through time and learn about history!',
    category: 'reading',
    difficulty: 'hard',
    levels: 15,
    currentLevel: 1,
    completed: false,
    stars: 0,
    icon: '⏰',
    color: 'bg-gradient-to-br from-indigo-500 to-purple-600',
    component: 'TimeTraveler'
  },
  {
    id: 'ocean-adventure',
    title: 'Ocean Adventure',
    description: 'Dive deep into the ocean and discover marine life!',
    category: 'creative',
    difficulty: 'medium',
    levels: 8,
    currentLevel: 1,
    completed: false,
    stars: 0,
    icon: '🌊',
    color: 'bg-gradient-to-br from-cyan-400 to-blue-500',
    component: 'OceanAdventure'
  },
  {
    id: 'robot-builder',
    title: 'Robot Builder',
    description: 'Build and program robots to complete fun tasks!',
    category: 'problem-solving',
    difficulty: 'hard',
    levels: 10,
    currentLevel: 1,
    completed: false,
    stars: 0,
    icon: '🤖',
    color: 'bg-gradient-to-br from-gray-400 to-slate-500',
    component: 'RobotBuilder'
  },
  {
    id: 'art-studio',
    title: 'Art Studio',
    description: 'Create amazing artwork with digital brushes and colors!',
    category: 'creative',
    difficulty: 'easy',
    levels: 5,
    currentLevel: 1,
    completed: false,
    stars: 0,
    icon: '🎭',
    color: 'bg-gradient-to-br from-pink-500 to-purple-600',
    component: 'ArtStudio'
  },
  {
    id: 'sports-star',
    title: 'Sports Star',
    description: 'Play different sports and improve your coordination!',
    category: 'motor-skills',
    difficulty: 'medium',
    levels: 8,
    currentLevel: 1,
    completed: false,
    stars: 0,
    icon: '⚽',
    color: 'bg-gradient-to-br from-green-500 to-emerald-600',
    component: 'SportsStar'
  },
  {
    id: 'nature-explorer',
    title: 'Nature Explorer',
    description: 'Explore nature and learn about plants and animals!',
    category: 'reading',
    difficulty: 'easy',
    levels: 6,
    currentLevel: 1,
    completed: false,
    stars: 0,
    icon: '🦋',
    color: 'bg-gradient-to-br from-emerald-400 to-teal-500',
    component: 'NatureExplorer'
  }
];

const initialState: GameState = {
  games: initialGames,
  currentGame: null,
  userProgress: {},
  adminMode: false
};

function gameReducer(state: GameState, action: GameAction): GameState {
  switch (action.type) {
    case 'SET_CURRENT_GAME':
      return { ...state, currentGame: action.payload };
    case 'UPDATE_PROGRESS':
      const { gameId, level, stars } = action.payload;
      return {
        ...state,
        userProgress: {
          ...state.userProgress,
          [gameId]: { level, stars, completed: level >= (state.games.find(g => g.id === gameId)?.levels || 0) }
        }
      };
    case 'TOGGLE_ADMIN_MODE':
      return { ...state, adminMode: !state.adminMode };
    case 'ADD_GAME':
      return { ...state, games: [...state.games, action.payload] };
    case 'UPDATE_GAME':
      return {
        ...state,
        games: state.games.map(game => game.id === action.payload.id ? action.payload : game)
      };
    case 'DELETE_GAME':
      return {
        ...state,
        games: state.games.filter(game => game.id !== action.payload)
      };
    default:
      return state;
  }
}

const GameContext = createContext<{
  state: GameState;
  dispatch: React.Dispatch<GameAction>;
} | null>(null);

export function GameProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(gameReducer, initialState);

  return (
    <GameContext.Provider value={{ state, dispatch }}>
      {children}
    </GameContext.Provider>
  );
}

export function useGame() {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
}