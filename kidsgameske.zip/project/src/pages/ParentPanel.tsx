import React, { useState } from 'react';
import { Shield, Clock, Volume2, Eye, Settings } from 'lucide-react';

export default function ParentPanel() {
  const [screenTimeLimit, setScreenTimeLimit] = useState(60);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [parentalControls, setParentalControls] = useState({
    restrictedGames: [],
    ageAppropriate: true,
    progressReports: true
  });

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-800 mb-2">Parent Panel</h1>
        <p className="text-gray-600">Manage your child's gaming experience with safety and learning in mind</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Screen Time Management */}
        <div className="bg-white rounded-xl p-6 shadow-lg">
          <div className="flex items-center space-x-3 mb-6">
            <div className="bg-blue-100 p-3 rounded-full">
              <Clock className="text-blue-600" size={24} />
            </div>
            <h2 className="text-xl font-bold text-gray-800">Screen Time</h2>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Daily Screen Time Limit
              </label>
              <div className="flex items-center space-x-4">
                <input
                  type="range"
                  min="15"
                  max="180"
                  value={screenTimeLimit}
                  onChange={(e) => setScreenTimeLimit(Number(e.target.value))}
                  className="flex-1"
                />
                <span className="text-lg font-semibold text-blue-600">
                  {screenTimeLimit} minutes
                </span>
              </div>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="text-sm text-blue-800">
                <strong>Today's Usage:</strong> 23 minutes remaining
              </p>
              <div className="w-full bg-blue-200 rounded-full h-2 mt-2">
                <div className="bg-blue-600 h-2 rounded-full" style={{ width: '62%' }}></div>
              </div>
            </div>
          </div>
        </div>

        {/* Safety Settings */}
        <div className="bg-white rounded-xl p-6 shadow-lg">
          <div className="flex items-center space-x-3 mb-6">
            <div className="bg-green-100 p-3 rounded-full">
              <Shield className="text-green-600" size={24} />
            </div>
            <h2 className="text-xl font-bold text-gray-800">Safety Settings</h2>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-gray-800">Age-Appropriate Content</p>
                <p className="text-sm text-gray-600">Only show suitable games</p>
              </div>
              <button
                onClick={() => setParentalControls(prev => ({ ...prev, ageAppropriate: !prev.ageAppropriate }))}
                className={`w-12 h-6 rounded-full ${parentalControls.ageAppropriate ? 'bg-green-500' : 'bg-gray-300'} transition-colors relative`}
              >
                <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform ${parentalControls.ageAppropriate ? 'translate-x-6' : 'translate-x-0.5'}`}></div>
              </button>
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-gray-800">Progress Reports</p>
                <p className="text-sm text-gray-600">Weekly learning summaries</p>
              </div>
              <button
                onClick={() => setParentalControls(prev => ({ ...prev, progressReports: !prev.progressReports }))}
                className={`w-12 h-6 rounded-full ${parentalControls.progressReports ? 'bg-green-500' : 'bg-gray-300'} transition-colors relative`}
              >
                <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform ${parentalControls.progressReports ? 'translate-x-6' : 'translate-x-0.5'}`}></div>
              </button>
            </div>
          </div>
        </div>

        {/* Audio Settings */}
        <div className="bg-white rounded-xl p-6 shadow-lg">
          <div className="flex items-center space-x-3 mb-6">
            <div className="bg-purple-100 p-3 rounded-full">
              <Volume2 className="text-purple-600" size={24} />
            </div>
            <h2 className="text-xl font-bold text-gray-800">Audio Settings</h2>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-gray-800">Sound Effects</p>
                <p className="text-sm text-gray-600">Game sounds and music</p>
              </div>
              <button
                onClick={() => setSoundEnabled(!soundEnabled)}
                className={`w-12 h-6 rounded-full ${soundEnabled ? 'bg-purple-500' : 'bg-gray-300'} transition-colors relative`}
              >
                <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform ${soundEnabled ? 'translate-x-6' : 'translate-x-0.5'}`}></div>
              </button>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Volume Level
              </label>
              <input
                type="range"
                min="0"
                max="100"
                defaultValue="70"
                className="w-full"
                disabled={!soundEnabled}
              />
            </div>
          </div>
        </div>

        {/* Progress Overview */}
        <div className="bg-white rounded-xl p-6 shadow-lg">
          <div className="flex items-center space-x-3 mb-6">
            <div className="bg-yellow-100 p-3 rounded-full">
              <Eye className="text-yellow-600" size={24} />
            </div>
            <h2 className="text-xl font-bold text-gray-800">Learning Progress</h2>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <span className="text-xl">🧠</span>
                <span className="font-medium">Memory Skills</span>
              </div>
              <div className="text-green-600 font-semibold">85%</div>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <span className="text-xl">🔢</span>
                <span className="font-medium">Math Skills</span>
              </div>
              <div className="text-blue-600 font-semibold">72%</div>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <span className="text-xl">📚</span>
                <span className="font-medium">Reading Skills</span>
              </div>
              <div className="text-purple-600 font-semibold">91%</div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="mt-8 bg-white rounded-xl p-6 shadow-lg">
        <h2 className="text-xl font-bold text-gray-800 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button className="flex items-center space-x-3 p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
            <Settings className="text-blue-600" size={20} />
            <span className="font-medium text-blue-800">Customize Games</span>
          </button>
          
          <button className="flex items-center space-x-3 p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors">
            <Shield className="text-green-600" size={20} />
            <span className="font-medium text-green-800">Safety Report</span>
          </button>
          
          <button className="flex items-center space-x-3 p-4 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors">
            <Eye className="text-purple-600" size={20} />
            <span className="font-medium text-purple-800">View Progress</span>
          </button>
        </div>
      </div>
    </div>
  );
}