import React, { useState } from 'react';
import { Plus, Edit, Trash2, BarChart3, Users, TowerControl as GameController2, X } from 'lucide-react';
import { useGame } from '../context/GameContext';

export default function AdminDashboard() {
  const { state, dispatch } = useGame();
  const [activeTab, setActiveTab] = useState('overview');
  const [showAddGameModal, setShowAddGameModal] = useState(false);
  const [newGame, setNewGame] = useState({
    title: '',
    description: '',
    category: 'problem-solving' as const,
    difficulty: 'easy' as const,
    levels: 5,
    icon: '🎮',
    color: 'bg-gradient-to-br from-blue-400 to-purple-500'
  });

  const tabs = [
    { id: 'overview', name: 'Overview', icon: BarChart3 },
    { id: 'games', name: 'Games', icon: GameController2 },
    { id: 'users', name: 'Users', icon: Users }
  ];

  const stats = {
    totalGames: state.games.length,
    totalPlayers: 1247, // Mock data
    totalPlaytime: '2,847 hours', // Mock data
    averageRating: 4.8 // Mock data
  };

  const categories = [
    'problem-solving',
    'memory',
    'math',
    'reading',
    'motor-skills',
    'creative'
  ];

  const difficulties = ['easy', 'medium', 'hard'];

  const colors = [
    'bg-gradient-to-br from-blue-400 to-purple-500',
    'bg-gradient-to-br from-green-400 to-blue-500',
    'bg-gradient-to-br from-pink-400 to-purple-500',
    'bg-gradient-to-br from-yellow-400 to-orange-500',
    'bg-gradient-to-br from-red-400 to-pink-500',
    'bg-gradient-to-br from-indigo-400 to-purple-500',
    'bg-gradient-to-br from-teal-400 to-cyan-500',
    'bg-gradient-to-br from-purple-400 to-pink-500'
  ];

  const handleAddGame = () => {
    const gameId = newGame.title.toLowerCase().replace(/\s+/g, '-');
    const game = {
      id: gameId,
      title: newGame.title,
      description: newGame.description,
      category: newGame.category,
      difficulty: newGame.difficulty,
      levels: newGame.levels,
      currentLevel: 1,
      completed: false,
      stars: 0,
      icon: newGame.icon,
      color: newGame.color,
      component: 'ComingSoon'
    };

    dispatch({ type: 'ADD_GAME', payload: game });
    setShowAddGameModal(false);
    setNewGame({
      title: '',
      description: '',
      category: 'problem-solving',
      difficulty: 'easy',
      levels: 5,
      icon: '🎮',
      color: 'bg-gradient-to-br from-blue-400 to-purple-500'
    });
  };

  const handleDeleteGame = (gameId: string) => {
    if (confirm('Are you sure you want to delete this game?')) {
      dispatch({ type: 'DELETE_GAME', payload: gameId });
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-800 mb-2">Admin Dashboard</h1>
        <p className="text-gray-600">Manage your educational gaming platform</p>
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-4 mb-8">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center space-x-2 px-6 py-3 rounded-lg transition-colors ${
              activeTab === tab.id
                ? 'bg-blue-500 text-white shadow-lg'
                : 'bg-white text-gray-600 hover:bg-blue-50'
            }`}
          >
            <tab.icon size={20} />
            <span>{tab.name}</span>
          </button>
        ))}
      </div>

      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white rounded-xl p-6 shadow-lg border-l-4 border-blue-500">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm">Total Games</p>
                  <p className="text-3xl font-bold text-gray-800">{stats.totalGames}</p>
                </div>
                <GameController2 className="text-blue-500" size={32} />
              </div>
            </div>
            
            <div className="bg-white rounded-xl p-6 shadow-lg border-l-4 border-green-500">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm">Total Players</p>
                  <p className="text-3xl font-bold text-gray-800">{stats.totalPlayers}</p>
                </div>
                <Users className="text-green-500" size={32} />
              </div>
            </div>
            
            <div className="bg-white rounded-xl p-6 shadow-lg border-l-4 border-purple-500">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm">Total Playtime</p>
                  <p className="text-3xl font-bold text-gray-800">{stats.totalPlaytime}</p>
                </div>
                <BarChart3 className="text-purple-500" size={32} />
              </div>
            </div>
            
            <div className="bg-white rounded-xl p-6 shadow-lg border-l-4 border-yellow-500">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm">Average Rating</p>
                  <p className="text-3xl font-bold text-gray-800">{stats.averageRating}</p>
                </div>
                <div className="text-yellow-500 text-2xl">⭐</div>
              </div>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <h3 className="text-xl font-bold text-gray-800 mb-4">Recent Activity</h3>
            <div className="space-y-4">
              {[
                { action: 'New player registered', time: '2 minutes ago', type: 'user' },
                { action: 'Memory Match game completed', time: '5 minutes ago', type: 'game' },
                { action: 'Math Adventure updated', time: '1 hour ago', type: 'update' },
                { action: 'New high score in Word Builder', time: '2 hours ago', type: 'achievement' }
              ].map((activity, index) => (
                <div key={index} className="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
                  <div className={`w-2 h-2 rounded-full ${
                    activity.type === 'user' ? 'bg-green-500' :
                    activity.type === 'game' ? 'bg-blue-500' :
                    activity.type === 'update' ? 'bg-yellow-500' :
                    'bg-purple-500'
                  }`}></div>
                  <div className="flex-1">
                    <p className="text-gray-800">{activity.action}</p>
                    <p className="text-gray-500 text-sm">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Games Tab */}
      {activeTab === 'games' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold text-gray-800">Games Management</h2>
            <button
              onClick={() => setShowAddGameModal(true)}
              className="flex items-center space-x-2 bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors"
            >
              <Plus size={20} />
              <span>Add New Game</span>
            </button>
          </div>

          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Game</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Levels</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Difficulty</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {state.games.map(game => (
                    <tr key={game.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="text-2xl mr-3">{game.icon}</div>
                          <div>
                            <div className="text-sm font-medium text-gray-900">{game.title}</div>
                            <div className="text-sm text-gray-500">{game.description}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                          {game.category}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {game.levels}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          game.difficulty === 'easy' ? 'bg-green-100 text-green-800' :
                          game.difficulty === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-red-100 text-red-800'
                        }`}>
                          {game.difficulty}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex space-x-2">
                          <button className="text-blue-600 hover:text-blue-900">
                            <Edit size={16} />
                          </button>
                          <button 
                            onClick={() => handleDeleteGame(game.id)}
                            className="text-red-600 hover:text-red-900"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Users Tab */}
      {activeTab === 'users' && (
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-gray-800">User Analytics</h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl p-6 shadow-lg">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">User Engagement</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Daily Active Users</span>
                  <span className="font-semibold">342</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Weekly Active Users</span>
                  <span className="font-semibold">1,247</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Monthly Active Users</span>
                  <span className="font-semibold">3,891</span>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-xl p-6 shadow-lg">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Popular Games</h3>
              <div className="space-y-3">
                {state.games.slice(0, 5).map((game, index) => (
                  <div key={game.id} className="flex items-center space-x-3">
                    <div className="text-lg">{game.icon}</div>
                    <div className="flex-1">
                      <div className="text-sm font-medium text-gray-900">{game.title}</div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-500 h-2 rounded-full" 
                          style={{ width: `${Math.random() * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Game Modal */}
      {showAddGameModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-3xl p-8 max-w-md mx-4 w-full">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-bold text-gray-800">Add New Game</h3>
              <button
                onClick={() => setShowAddGameModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X size={24} />
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Game Title
                </label>
                <input
                  type="text"
                  value={newGame.title}
                  onChange={(e) => setNewGame({ ...newGame, title: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter game title"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Description
                </label>
                <textarea
                  value={newGame.description}
                  onChange={(e) => setNewGame({ ...newGame, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows={3}
                  placeholder="Enter game description"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Icon (Emoji)
                </label>
                <input
                  type="text"
                  value={newGame.icon}
                  onChange={(e) => setNewGame({ ...newGame, icon: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="🎮"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Category
                  </label>
                  <select
                    value={newGame.category}
                    onChange={(e) => setNewGame({ ...newGame, category: e.target.value as any })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {categories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Difficulty
                  </label>
                  <select
                    value={newGame.difficulty}
                    onChange={(e) => setNewGame({ ...newGame, difficulty: e.target.value as any })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {difficulties.map(diff => (
                      <option key={diff} value={diff}>{diff}</option>
                    ))}
                  </select>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Number of Levels
                </label>
                <input
                  type="number"
                  min="1"
                  max="20"
                  value={newGame.levels}
                  onChange={(e) => setNewGame({ ...newGame, levels: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Color Theme
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {colors.map((color, index) => (
                    <button
                      key={index}
                      onClick={() => setNewGame({ ...newGame, color })}
                      className={`w-12 h-12 rounded-lg ${color} ${
                        newGame.color === color ? 'ring-4 ring-blue-500' : ''
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>
            
            <div className="flex space-x-4 mt-6">
              <button
                onClick={() => setShowAddGameModal(false)}
                className="flex-1 bg-gray-500 text-white py-3 rounded-lg hover:bg-gray-600 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleAddGame}
                disabled={!newGame.title || !newGame.description}
                className="flex-1 bg-blue-500 text-white py-3 rounded-lg hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Add Game
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}