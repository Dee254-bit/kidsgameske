import React, { useState } from 'react';
import { Search, Filter } from 'lucide-react';
import { useGame } from '../context/GameContext';
import GameCard from '../components/GameCard';

const categories = [
  { id: 'all', name: 'All Games', icon: '🎮' },
  { id: 'memory', name: 'Memory', icon: '🧠' },
  { id: 'math', name: 'Math', icon: '🔢' },
  { id: 'reading', name: 'Reading', icon: '📚' },
  { id: 'problem-solving', name: 'Problem Solving', icon: '🧩' },
  { id: 'creative', name: 'Creative', icon: '🎨' },
  { id: 'motor-skills', name: 'Motor Skills', icon: '⚡' }
];

export default function HomePage() {
  const { state } = useGame();
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredGames = state.games.filter(game => {
    const matchesCategory = selectedCategory === 'all' || game.category === selectedCategory;
    const matchesSearch = game.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         game.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto">
      {/* Hero Section */}
      <div className="text-center mb-12">
        <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent mb-4">
          Welcome to KidsPlay! 🎉
        </h1>
        <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
          Discover amazing educational games designed just for you! Learn, play, and have fun while developing new skills.
        </p>
        
        {/* Search Bar */}
        <div className="max-w-md mx-auto mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Search for games..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-full focus:border-blue-500 focus:outline-none text-lg"
            />
          </div>
        </div>
      </div>

      {/* Category Filter */}
      <div className="mb-8">
        <div className="flex items-center space-x-2 mb-4">
          <Filter size={20} className="text-gray-600" />
          <span className="text-gray-600 font-medium">Choose a category:</span>
        </div>
        <div className="flex flex-wrap gap-3">
          {categories.map(category => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`flex items-center space-x-2 px-6 py-3 rounded-full transition-all duration-200 text-sm font-medium ${
                selectedCategory === category.id
                  ? 'bg-blue-500 text-white shadow-lg scale-105'
                  : 'bg-white text-gray-600 hover:bg-blue-50 border-2 border-gray-200'
              }`}
            >
              <span className="text-lg">{category.icon}</span>
              <span>{category.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Games Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredGames.map(game => (
          <GameCard
            key={game.id}
            game={game}
            progress={state.userProgress[game.id]}
          />
        ))}
      </div>

      {/* No games found */}
      {filteredGames.length === 0 && (
        <div className="text-center py-16">
          <div className="text-6xl mb-4">😢</div>
          <h3 className="text-2xl font-bold text-gray-600 mb-2">No games found</h3>
          <p className="text-gray-500">Try searching for something else or select a different category!</p>
        </div>
      )}

      {/* Stats Section */}
      <div className="mt-16 text-center">
        <h2 className="text-3xl font-bold text-gray-800 mb-4">Amazing Games Available! 🎮</h2>
        <p className="text-gray-600 mb-8">We now have {state.games.length} exciting games for you to enjoy!</p>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto">
          <div className="bg-blue-100 rounded-2xl p-4">
            <div className="text-3xl mb-2">🧠</div>
            <div className="text-sm font-medium text-blue-800">Memory Games</div>
            <div className="text-lg font-bold text-blue-900">
              {state.games.filter(g => g.category === 'memory').length}
            </div>
          </div>
          
          <div className="bg-green-100 rounded-2xl p-4">
            <div className="text-3xl mb-2">🔢</div>
            <div className="text-sm font-medium text-green-800">Math Games</div>
            <div className="text-lg font-bold text-green-900">
              {state.games.filter(g => g.category === 'math').length}
            </div>
          </div>
          
          <div className="bg-purple-100 rounded-2xl p-4">
            <div className="text-3xl mb-2">🧩</div>
            <div className="text-sm font-medium text-purple-800">Puzzle Games</div>
            <div className="text-lg font-bold text-purple-900">
              {state.games.filter(g => g.category === 'problem-solving').length}
            </div>
          </div>
          
          <div className="bg-pink-100 rounded-2xl p-4">
            <div className="text-3xl mb-2">🎨</div>
            <div className="text-sm font-medium text-pink-800">Creative Games</div>
            <div className="text-lg font-bold text-pink-900">
              {state.games.filter(g => g.category === 'creative').length}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}