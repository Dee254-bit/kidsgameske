import React, { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Home, RotateCcw } from 'lucide-react';
import { useGame } from '../context/GameContext';
import MemoryMatch from '../games/MemoryMatch';
import MathAdventure from '../games/MathAdventure';
import WordBuilder from '../games/WordBuilder';
import ColorMixer from '../games/ColorMixer';
import ShapeSorter from '../games/ShapeSorter';
import NumberCounter from '../games/NumberCounter';
import PatternPuzzle from '../games/PatternPuzzle';
import AnimalSounds from '../games/AnimalSounds';
import ComingSoon from '../games/ComingSoon';

const gameComponents = {
  MemoryMatch,
  MathAdventure,
  WordBuilder,
  ColorMixer,
  ShapeSorter,
  NumberCounter,
  PatternPuzzle,
  AnimalSounds,
  ComingSoon,
  // New game components (all using ComingSoon for now)
  PuzzleMaster: ComingSoon,
  SpaceExplorer: ComingSoon,
  GardenHelper: ComingSoon,
  MusicMaker: ComingSoon,
  ChefChallenge: ComingSoon,
  TreasureHunt: ComingSoon,
  TimeTraveler: ComingSoon,
  OceanAdventure: ComingSoon,
  RobotBuilder: ComingSoon,
  ArtStudio: ComingSoon,
  SportsStar: ComingSoon,
  NatureExplorer: ComingSoon
};

export default function GamePage() {
  const { gameId } = useParams();
  const navigate = useNavigate();
  const { state, dispatch } = useGame();
  
  const game = state.games.find(g => g.id === gameId);
  
  useEffect(() => {
    if (game) {
      dispatch({ type: 'SET_CURRENT_GAME', payload: game });
    }
  }, [game, dispatch]);

  if (!game) {
    return (
      <div className="text-center py-16">
        <div className="text-6xl mb-4">😵</div>
        <h2 className="text-2xl font-bold text-gray-600 mb-4">Game not found!</h2>
        <button
          onClick={() => navigate('/')}
          className="bg-blue-500 text-white px-6 py-3 rounded-full hover:bg-blue-600 transition-colors"
        >
          Go back to games
        </button>
      </div>
    );
  }

  const GameComponent = gameComponents[game.component as keyof typeof gameComponents];
  
  if (!GameComponent) {
    return (
      <div className="text-center py-16">
        <div className="text-6xl mb-4">🚧</div>
        <h2 className="text-2xl font-bold text-gray-600 mb-4">Coming Soon!</h2>
        <p className="text-gray-500 mb-6">This game is still in development. Check back soon!</p>
        <button
          onClick={() => navigate('/')}
          className="bg-blue-500 text-white px-6 py-3 rounded-full hover:bg-blue-600 transition-colors"
        >
          Go back to games
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      {/* Game Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => navigate('/')}
            className="flex items-center space-x-2 bg-white text-gray-600 px-4 py-2 rounded-full hover:bg-gray-100 transition-colors shadow-md"
          >
            <ArrowLeft size={20} />
            <span>Back to Games</span>
          </button>
        </div>
        
        <div className="flex items-center space-x-4">
          <button
            onClick={() => window.location.reload()}
            className="flex items-center space-x-2 bg-yellow-500 text-white px-4 py-2 rounded-full hover:bg-yellow-600 transition-colors shadow-md"
          >
            <RotateCcw size={20} />
            <span>Restart</span>
          </button>
          
          <button
            onClick={() => navigate('/')}
            className="flex items-center space-x-2 bg-blue-500 text-white px-4 py-2 rounded-full hover:bg-blue-600 transition-colors shadow-md"
          >
            <Home size={20} />
            <span>Home</span>
          </button>
        </div>
      </div>

      {/* Game Container */}
      <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
        <div className={`${game.color} p-6 text-center`}>
          <div className="text-5xl mb-2">{game.icon}</div>
          <h1 className="text-white text-3xl font-bold mb-2">{game.title}</h1>
          <p className="text-white text-opacity-90">{game.description}</p>
        </div>
        
        <div className="p-6">
          <GameComponent 
            gameId={game.id}
            onProgress={(level: number, stars: number) => {
              dispatch({ 
                type: 'UPDATE_PROGRESS', 
                payload: { gameId: game.id, level, stars } 
              });
            }}
          />
        </div>
      </div>
    </div>
  );
}