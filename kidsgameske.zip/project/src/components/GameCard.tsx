import React from 'react';
import { Link } from 'react-router-dom';
import { Play, Star, Trophy } from 'lucide-react';
import { Game } from '../context/GameContext';

interface GameCardProps {
  game: Game;
  progress?: { level: number; stars: number; completed: boolean };
}

export default function GameCard({ game, progress }: GameCardProps) {
  const isCompleted = progress?.completed || false;
  const currentLevel = progress?.level || 1;
  const stars = progress?.stars || 0;

  return (
    <Link to={`/game/${game.id}`} className="block group">
      <div className={`${game.color} rounded-3xl p-6 shadow-lg hover:shadow-xl transform hover:-translate-y-2 transition-all duration-300 relative overflow-hidden`}>
        {/* Decorative elements */}
        <div className="absolute -top-4 -right-4 w-16 h-16 bg-white bg-opacity-20 rounded-full"></div>
        <div className="absolute -bottom-2 -left-2 w-12 h-12 bg-white bg-opacity-15 rounded-full"></div>
        
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-4">
            <div className="text-4xl">{game.icon}</div>
            {isCompleted && (
              <div className="bg-yellow-400 rounded-full p-2">
                <Trophy className="text-yellow-800" size={16} />
              </div>
            )}
          </div>
          
          <h3 className="text-white text-xl font-bold mb-2">{game.title}</h3>
          <p className="text-white text-opacity-90 text-sm mb-4 line-clamp-2">
            {game.description}
          </p>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="bg-white bg-opacity-20 rounded-full px-3 py-1">
                <span className="text-white text-xs font-medium">
                  Level {currentLevel}/{game.levels}
                </span>
              </div>
              {stars > 0 && (
                <div className="flex items-center space-x-1">
                  {[...Array(Math.min(stars, 3))].map((_, i) => (
                    <Star key={i} className="text-yellow-300 fill-current" size={16} />
                  ))}
                </div>
              )}
            </div>
            
            <div className="bg-white bg-opacity-20 rounded-full p-2 group-hover:bg-opacity-30 transition-all duration-200">
              <Play className="text-white" size={20} />
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}