import React from 'react';
import { Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-white border-t-4 border-rainbow mt-16">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <span className="text-gray-600">Made with</span>
            <Heart className="text-red-500 fill-current" size={20} />
            <span className="text-gray-600">for kids everywhere</span>
          </div>
          <p className="text-gray-500 text-sm">
            Safe, fun, and educational games for children. Always free to play!
          </p>
        </div>
      </div>
    </footer>
  );
}