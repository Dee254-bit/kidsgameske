import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Settings, Users } from 'lucide-react';

export default function Header() {
  const location = useLocation();
  
  return (
    <header className="bg-white shadow-lg border-b-4 border-rainbow">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-2xl font-bold">
              K
            </div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              KidsPlay
            </h1>
          </Link>
          
          <nav className="flex items-center space-x-4">
            <Link
              to="/"
              className={`flex items-center space-x-2 px-4 py-2 rounded-full transition-all duration-200 ${
                location.pathname === '/' 
                  ? 'bg-blue-500 text-white shadow-lg' 
                  : 'text-gray-600 hover:bg-blue-100'
              }`}
            >
              <Home size={20} />
              <span className="hidden sm:inline">Home</span>
            </Link>
            
            <Link
              to="/parents"
              className={`flex items-center space-x-2 px-4 py-2 rounded-full transition-all duration-200 ${
                location.pathname === '/parents' 
                  ? 'bg-green-500 text-white shadow-lg' 
                  : 'text-gray-600 hover:bg-green-100'
              }`}
            >
              <Users size={20} />
              <span className="hidden sm:inline">Parents</span>
            </Link>
            
            <Link
              to="/admin"
              className={`flex items-center space-x-2 px-4 py-2 rounded-full transition-all duration-200 ${
                location.pathname === '/admin' 
                  ? 'bg-purple-500 text-white shadow-lg' 
                  : 'text-gray-600 hover:bg-purple-100'
              }`}
            >
              <Settings size={20} />
              <span className="hidden sm:inline">Admin</span>
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}