import React, { useState, useEffect } from 'react';
import { Star, RefreshCw, Lightbulb } from 'lucide-react';

interface PatternPuzzleProps {
  gameId: string;
  onProgress: (level: number, stars: number) => void;
}

const shapes = ['🔴', '🔵', '🟡', '🟢', '🟠', '🟣'];
const patterns = {
  1: [
    ['🔴', '🔵', '🔴', '🔵', '?'],
    ['🟡', '🟢', '🟡', '🟢', '?'],
    ['🔴', '🔴', '🔵', '🔴', '🔴', '🔵', '?']
  ],
  2: [
    ['🔴', '🔵', '🔵', '🔴', '🔵', '🔵', '?'],
    ['🟡', '🟢', '🟠', '🟡', '🟢', '🟠', '?'],
    ['🔴', '🔵', '🟡', '🔴', '🔵', '🟡', '?']
  ],
  3: [
    ['🔴', '🔵', '🟡', '🟢', '🔴', '🔵', '🟡', '?'],
    ['🔴', '🔴', '🔵', '🔴', '🔴', '🔵', '?'],
    ['🟡', '🟢', '🟠', '🟣', '🟡', '🟢', '🟠', '?']
  ]
};

export default function PatternPuzzle({ gameId, onProgress }: PatternPuzzleProps) {
  const [level, setLevel] = useState(1);
  const [currentPattern, setCurrentPattern] = useState<string[]>([]);
  const [correctAnswer, setCorrectAnswer] = useState('');
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [showHint, setShowHint] = useState(false);
  const [patternsCompleted, setPatternsCompleted] = useState(0);
  const [stars, setStars] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [hintsUsed, setHintsUsed] = useState(0);

  const generatePattern = () => {
    const levelPatterns = patterns[level as keyof typeof patterns];
    const selectedPattern = levelPatterns[Math.floor(Math.random() * levelPatterns.length)];
    
    // Get the pattern without the '?' and determine the correct answer
    const patternWithoutQuestion = selectedPattern.slice(0, -1);
    const answer = getPatternAnswer(patternWithoutQuestion);
    
    setCurrentPattern(selectedPattern);
    setCorrectAnswer(answer);
    setSelectedAnswer(null);
    setIsCorrect(null);
    setShowHint(false);
  };

  const getPatternAnswer = (pattern: string[]): string => {
    // Simple pattern detection logic
    const len = pattern.length;
    
    // Check for simple repeating patterns
    if (len >= 2) {
      // Check if it's a simple AB pattern
      if (len % 2 === 0) {
        const isABPattern = pattern.every((item, index) => 
          index % 2 === 0 ? item === pattern[0] : item === pattern[1]
        );
        if (isABPattern) {
          return len % 2 === 0 ? pattern[0] : pattern[1];
        }
      }
      
      // Check for ABC pattern
      if (len >= 3 && len % 3 === 0) {
        const isABCPattern = pattern.every((item, index) => 
          item === pattern[index % 3]
        );
        if (isABCPattern) {
          return pattern[0];
        }
      }
      
      // Check for ABCD pattern
      if (len >= 4 && len % 4 === 0) {
        const isABCDPattern = pattern.every((item, index) => 
          item === pattern[index % 4]
        );
        if (isABCDPattern) {
          return pattern[0];
        }
      }
    }
    
    // Fallback: return the most common item or first item
    return pattern[0];
  };

  useEffect(() => {
    generatePattern();
  }, [level]);

  const handleAnswerClick = (answer: string) => {
    if (selectedAnswer !== null) return;
    
    setSelectedAnswer(answer);
    const correct = answer === correctAnswer;
    setIsCorrect(correct);
    
    if (correct) {
      const newPatternsCompleted = patternsCompleted + 1;
      setPatternsCompleted(newPatternsCompleted);
      
      setTimeout(() => {
        if (newPatternsCompleted >= 3) {
          // Level complete
          const earnedStars = hintsUsed === 0 ? 3 : hintsUsed <= 1 ? 2 : 1;
          setStars(earnedStars);
          setShowResult(true);
          onProgress(level, earnedStars);
        } else {
          generatePattern();
        }
      }, 1500);
    } else {
      setTimeout(() => {
        setSelectedAnswer(null);
        setIsCorrect(null);
      }, 1500);
    }
  };

  const showHintHandler = () => {
    setShowHint(true);
    setHintsUsed(hintsUsed + 1);
  };

  const getHintText = () => {
    const pattern = currentPattern.slice(0, -1);
    const len = pattern.length;
    
    if (len >= 2 && len % 2 === 0) {
      const isABPattern = pattern.every((item, index) => 
        index % 2 === 0 ? item === pattern[0] : item === pattern[1]
      );
      if (isABPattern) {
        return `This pattern alternates between two shapes: ${pattern[0]} and ${pattern[1]}`;
      }
    }
    
    if (len >= 3 && len % 3 === 0) {
      return `This pattern repeats every 3 shapes: ${pattern[0]}, ${pattern[1]}, ${pattern[2]}`;
    }
    
    return 'Look for the repeating sequence in the pattern!';
  };

  const nextLevel = () => {
    if (level < 6) {
      setLevel(level + 1);
      resetGame();
    }
  };

  const resetGame = () => {
    setPatternsCompleted(0);
    setHintsUsed(0);
    setShowResult(false);
    generatePattern();
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Game Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          <h2 className="text-2xl font-bold text-gray-800">Level {level}</h2>
          <span className="text-gray-600">Patterns: {patternsCompleted}/3</span>
        </div>
        
        <div className="flex items-center space-x-2">
          <button
            onClick={showHintHandler}
            className="flex items-center space-x-2 bg-yellow-500 text-white px-4 py-2 rounded-lg hover:bg-yellow-600 transition-colors"
          >
            <Lightbulb size={20} />
            <span>Hint</span>
          </button>
          
          <button
            onClick={resetGame}
            className="flex items-center space-x-2 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
          >
            <RefreshCw size={20} />
            <span>Restart</span>
          </button>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-gray-200 rounded-full h-3 mb-8">
        <div 
          className="bg-blue-500 h-3 rounded-full transition-all duration-300"
          style={{ width: `${(patternsCompleted / 3) * 100}%` }}
        ></div>
      </div>

      {/* Hint */}
      {showHint && (
        <div className="bg-yellow-100 border-l-4 border-yellow-500 p-4 mb-6 rounded-lg">
          <div className="flex items-center space-x-2">
            <Lightbulb className="text-yellow-600" size={20} />
            <p className="text-yellow-800 font-medium">{getHintText()}</p>
          </div>
        </div>
      )}

      {/* Pattern Display */}
      <div className="text-center mb-8">
        <h3 className="text-2xl font-bold text-gray-800 mb-6">
          Complete the pattern!
        </h3>
        
        <div className="bg-white rounded-3xl p-8 shadow-lg mb-8">
          <div className="flex justify-center items-center space-x-4 flex-wrap">
            {currentPattern.map((item, index) => (
              <div
                key={index}
                className={`w-16 h-16 flex items-center justify-center text-4xl rounded-full transition-all duration-200 ${
                  item === '?' 
                    ? 'bg-gray-200 border-2 border-dashed border-gray-400' 
                    : 'bg-gray-50 shadow-md'
                }`}
              >
                {item === '?' ? '?' : item}
              </div>
            ))}
          </div>
        </div>

        {/* Answer Options */}
        <div className="grid grid-cols-3 md:grid-cols-6 gap-4 max-w-2xl mx-auto">
          {shapes.map((shape, index) => (
            <button
              key={index}
              onClick={() => handleAnswerClick(shape)}
              disabled={selectedAnswer !== null}
              className={`w-16 h-16 text-3xl rounded-full transition-all duration-200 ${
                selectedAnswer === shape
                  ? isCorrect
                    ? 'bg-green-500 text-white shadow-lg scale-110'
                    : 'bg-red-500 text-white shadow-lg scale-110'
                  : selectedAnswer !== null
                    ? shape === correctAnswer
                      ? 'bg-green-500 text-white shadow-lg'
                      : 'bg-gray-200 opacity-50'
                    : 'bg-blue-100 hover:bg-blue-200 hover:scale-105 shadow-md'
              }`}
            >
              {shape}
            </button>
          ))}
        </div>

        {/* Feedback */}
        {isCorrect !== null && (
          <div className="mt-6">
            <div className={`inline-flex items-center space-x-2 px-6 py-3 rounded-full ${
              isCorrect ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
            }`}>
              <span className="text-2xl">{isCorrect ? '🧩' : '🤔'}</span>
              <span className="font-bold">
                {isCorrect ? 'Perfect! You found the pattern!' : 'Try again! Look for the pattern.'}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Result Modal */}
      {showResult && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-3xl p-8 text-center max-w-md mx-4">
            <div className="text-6xl mb-4">🧩</div>
            <h3 className="text-2xl font-bold text-gray-800 mb-2">Level Complete!</h3>
            <p className="text-gray-600 mb-4">You're a pattern master!</p>
            
            <div className="flex justify-center space-x-1 mb-6">
              {[...Array(3)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-8 h-8 ${i < stars ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
                />
              ))}
            </div>
            
            <div className="flex space-x-4">
              <button
                onClick={resetGame}
                className="flex-1 bg-gray-500 text-white py-3 rounded-lg hover:bg-gray-600 transition-colors"
              >
                Play Again
              </button>
              {level < 6 && (
                <button
                  onClick={nextLevel}
                  className="flex-1 bg-green-500 text-white py-3 rounded-lg hover:bg-green-600 transition-colors"
                >
                  Next Level
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}