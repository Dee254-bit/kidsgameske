import React, { useState, useEffect } from 'react';
import { Star, RefreshCw, Lightbulb } from 'lucide-react';

interface WordBuilderProps {
  gameId: string;
  onProgress: (level: number, stars: number) => void;
}

const wordLists = {
  1: ['CAT', 'DOG', 'SUN', 'BOX'],
  2: ['FISH', 'BIRD', 'TREE', 'MOON'],
  3: ['HOUSE', 'HAPPY', 'WATER', 'GAMES'],
  4: ['FRIEND', 'SCHOOL', 'GARDEN', 'PUZZLE'],
  5: ['RAINBOW', 'MONSTER', 'DIAMOND', 'FANTASY'],
  6: ['ELEPHANT', 'TREASURE', 'BIRTHDAY', 'COMPUTER']
};

export default function WordBuilder({ gameId, onProgress }: WordBuilderProps) {
  const [level, setLevel] = useState(1);
  const [currentWord, setCurrentWord] = useState('');
  const [shuffledLetters, setShuffledLetters] = useState<string[]>([]);
  const [userWord, setUserWord] = useState('');
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [showHint, setShowHint] = useState(false);
  const [wordsCompleted, setWordsCompleted] = useState(0);
  const [stars, setStars] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [hintsUsed, setHintsUsed] = useState(0);

  const generateWord = () => {
    const words = wordLists[level as keyof typeof wordLists];
    const word = words[Math.floor(Math.random() * words.length)];
    setCurrentWord(word);
    
    // Shuffle letters
    const letters = word.split('');
    for (let i = letters.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [letters[i], letters[j]] = [letters[j], letters[i]];
    }
    setShuffledLetters(letters);
    setUserWord('');
    setIsCorrect(null);
    setShowHint(false);
  };

  useEffect(() => {
    generateWord();
  }, [level]);

  const handleLetterClick = (letter: string, index: number) => {
    if (userWord.length < currentWord.length) {
      setUserWord(userWord + letter);
      setShuffledLetters(prev => prev.filter((_, i) => i !== index));
    }
  };

  const handleRemoveLetter = (index: number) => {
    const removedLetter = userWord[index];
    setUserWord(userWord.slice(0, index) + userWord.slice(index + 1));
    setShuffledLetters(prev => [...prev, removedLetter]);
  };

  const checkAnswer = () => {
    if (userWord.length !== currentWord.length) return;
    
    const correct = userWord.toUpperCase() === currentWord.toUpperCase();
    setIsCorrect(correct);
    
    if (correct) {
      const newWordsCompleted = wordsCompleted + 1;
      setWordsCompleted(newWordsCompleted);
      
      setTimeout(() => {
        if (newWordsCompleted >= 3) {
          // Level complete
          const earnedStars = hintsUsed === 0 ? 3 : hintsUsed <= 1 ? 2 : 1;
          setStars(earnedStars);
          setShowResult(true);
          onProgress(level, earnedStars);
        } else {
          generateWord();
        }
      }, 1500);
    }
  };

  useEffect(() => {
    if (userWord.length === currentWord.length) {
      checkAnswer();
    }
  }, [userWord]);

  const showHintHandler = () => {
    setShowHint(true);
    setHintsUsed(hintsUsed + 1);
  };

  const nextLevel = () => {
    if (level < 6) {
      setLevel(level + 1);
      resetGame();
    }
  };

  const resetGame = () => {
    setWordsCompleted(0);
    setHintsUsed(0);
    setShowResult(false);
    generateWord();
  };

  const getHintText = () => {
    const hints: Record<string, string> = {
      'CAT': 'A furry pet that says meow',
      'DOG': 'A loyal pet that barks',
      'SUN': 'It shines bright in the sky',
      'BOX': 'You can put things inside this',
      'FISH': 'It swims in water',
      'BIRD': 'It has wings and can fly',
      'TREE': 'It has leaves and grows tall',
      'MOON': 'You see this at night',
      'HOUSE': 'Where people live',
      'HAPPY': 'Feeling good and smiling',
      'WATER': 'You drink this when thirsty',
      'GAMES': 'Fun activities to play',
      'FRIEND': 'Someone you like to play with',
      'SCHOOL': 'Where you go to learn',
      'GARDEN': 'Where flowers and plants grow',
      'PUZZLE': 'A game with pieces to solve',
      'RAINBOW': 'Colorful arc in the sky',
      'MONSTER': 'A scary but friendly creature',
      'DIAMOND': 'A shiny precious stone',
      'FANTASY': 'Magical and imaginary stories',
      'ELEPHANT': 'Large animal with a trunk',
      'TREASURE': 'Valuable things like gold',
      'BIRTHDAY': 'The day you were born',
      'COMPUTER': 'A machine for playing games'
    };
    return hints[currentWord] || 'Think about what this word means!';
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Game Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          <h2 className="text-2xl font-bold text-gray-800">Level {level}</h2>
          <span className="text-gray-600">Words: {wordsCompleted}/3</span>
        </div>
        
        <div className="flex items-center space-x-2">
          <button
            onClick={showHintHandler}
            className="flex items-center space-x-2 bg-yellow-500 text-white px-4 py-2 rounded-lg hover:bg-yellow-600 transition-colors"
          >
            <Lightbulb size={20} />
            <span>Hint</span>
          </button>
          
          <button
            onClick={resetGame}
            className="flex items-center space-x-2 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
          >
            <RefreshCw size={20} />
            <span>Restart</span>
          </button>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-gray-200 rounded-full h-3 mb-8">
        <div 
          className="bg-blue-500 h-3 rounded-full transition-all duration-300"
          style={{ width: `${(wordsCompleted / 3) * 100}%` }}
        ></div>
      </div>

      {/* Hint */}
      {showHint && (
        <div className="bg-yellow-100 border-l-4 border-yellow-500 p-4 mb-6 rounded-lg">
          <div className="flex items-center space-x-2">
            <Lightbulb className="text-yellow-600" size={20} />
            <p className="text-yellow-800 font-medium">{getHintText()}</p>
          </div>
        </div>
      )}

      {/* Word Building Area */}
      <div className="text-center mb-8">
        <h3 className="text-2xl font-bold text-gray-800 mb-6">Build the word!</h3>
        
        {/* User's Word */}
        <div className="flex justify-center space-x-2 mb-8">
          {Array.from({ length: currentWord.length }).map((_, index) => (
            <div
              key={index}
              onClick={() => userWord[index] && handleRemoveLetter(index)}
              className={`w-16 h-16 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center text-2xl font-bold cursor-pointer transition-all duration-200 ${
                userWord[index] 
                  ? isCorrect === true 
                    ? 'bg-green-500 text-white border-green-500 shadow-lg'
                    : isCorrect === false
                      ? 'bg-red-500 text-white border-red-500 shadow-lg'
                      : 'bg-blue-500 text-white border-blue-500 hover:bg-blue-600'
                  : 'hover:border-gray-400'
              }`}
            >
              {userWord[index] || ''}
            </div>
          ))}
        </div>

        {/* Available Letters */}
        <div className="flex flex-wrap justify-center gap-3">
          {shuffledLetters.map((letter, index) => (
            <button
              key={index}
              onClick={() => handleLetterClick(letter, index)}
              className="w-12 h-12 bg-gray-200 text-xl font-bold rounded-lg hover:bg-gray-300 transition-colors"
            >
              {letter}
            </button>
          ))}
        </div>

        {/* Feedback */}
        {isCorrect !== null && (
          <div className="mt-6">
            <div className={`inline-flex items-center space-x-2 px-6 py-3 rounded-full ${
              isCorrect ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
            }`}>
              <span className="text-2xl">{isCorrect ? '🎉' : '😅'}</span>
              <span className="font-bold">
                {isCorrect ? 'Correct! Great job!' : 'Try again!'}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Result Modal */}
      {showResult && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-3xl p-8 text-center max-w-md mx-4">
            <div className="text-6xl mb-4">📚</div>
            <h3 className="text-2xl font-bold text-gray-800 mb-2">Level Complete!</h3>
            <p className="text-gray-600 mb-4">You built all the words correctly!</p>
            
            <div className="flex justify-center space-x-1 mb-6">
              {[...Array(3)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-8 h-8 ${i < stars ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
                />
              ))}
            </div>
            
            <div className="flex space-x-4">
              <button
                onClick={resetGame}
                className="flex-1 bg-gray-500 text-white py-3 rounded-lg hover:bg-gray-600 transition-colors"
              >
                Play Again
              </button>
              {level < 6 && (
                <button
                  onClick={nextLevel}
                  className="flex-1 bg-green-500 text-white py-3 rounded-lg hover:bg-green-600 transition-colors"
                >
                  Next Level
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}