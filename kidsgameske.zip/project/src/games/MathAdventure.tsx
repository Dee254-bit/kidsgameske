import React, { useState, useEffect } from 'react';
import { Star, Trophy, RefreshCw } from 'lucide-react';

interface MathAdventureProps {
  gameId: string;
  onProgress: (level: number, stars: number) => void;
}

interface Question {
  num1: number;
  num2: number;
  operator: '+' | '-' | '*';
  answer: number;
  options: number[];
}

export default function MathAdventure({ gameId, onProgress }: MathAdventureProps) {
  const [level, setLevel] = useState(1);
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [score, setScore] = useState(0);
  const [questionsAnswered, setQuestionsAnswered] = useState(0);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [stars, setStars] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const generateQuestion = (): Question => {
    const maxNum = Math.min(5 + level * 2, 12);
    let num1 = Math.floor(Math.random() * maxNum) + 1;
    let num2 = Math.floor(Math.random() * maxNum) + 1;
    let operator: '+' | '-' | '*' = '+';
    
    if (level > 2) {
      const operators: ('+' | '-' | '*')[] = ['+', '-'];
      if (level > 4) operators.push('*');
      operator = operators[Math.floor(Math.random() * operators.length)];
    }
    
    // Ensure subtraction doesn't result in negative numbers
    if (operator === '-' && num1 < num2) {
      [num1, num2] = [num2, num1];
    }
    
    let answer: number;
    switch (operator) {
      case '+':
        answer = num1 + num2;
        break;
      case '-':
        answer = num1 - num2;
        break;
      case '*':
        answer = num1 * num2;
        break;
    }
    
    // Generate wrong options
    const options = [answer];
    while (options.length < 4) {
      const wrongAnswer = Math.max(1, answer + Math.floor(Math.random() * 10) - 5);
      if (!options.includes(wrongAnswer)) {
        options.push(wrongAnswer);
      }
    }
    
    // Shuffle options
    for (let i = options.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [options[i], options[j]] = [options[j], options[i]];
    }
    
    return { num1, num2, operator, answer, options };
  };

  useEffect(() => {
    setCurrentQuestion(generateQuestion());
  }, [level]);

  const handleAnswerClick = (selectedAnswer: number) => {
    if (isCorrect !== null) return;
    
    setSelectedAnswer(selectedAnswer);
    const correct = selectedAnswer === currentQuestion?.answer;
    setIsCorrect(correct);
    
    if (correct) {
      setScore(score + 1);
    }
    
    setTimeout(() => {
      const newQuestionsAnswered = questionsAnswered + 1;
      setQuestionsAnswered(newQuestionsAnswered);
      
      if (newQuestionsAnswered >= 5) {
        // Level complete
        const earnedStars = score >= 4 ? 3 : score >= 3 ? 2 : 1;
        setStars(earnedStars);
        setShowResult(true);
        onProgress(level, earnedStars);
      } else {
        setCurrentQuestion(generateQuestion());
        setIsCorrect(null);
        setSelectedAnswer(null);
      }
    }, 1500);
  };

  const nextLevel = () => {
    if (level < 8) {
      setLevel(level + 1);
      resetGame();
    }
  };

  const resetGame = () => {
    setScore(0);
    setQuestionsAnswered(0);
    setIsCorrect(null);
    setSelectedAnswer(null);
    setShowResult(false);
    setCurrentQuestion(generateQuestion());
  };

  if (!currentQuestion) return <div>Loading...</div>;

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Game Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          <h2 className="text-2xl font-bold text-gray-800">Level {level}</h2>
          <div className="flex items-center space-x-4">
            <span className="text-gray-600">Score: {score}/5</span>
            <span className="text-gray-600">Question: {questionsAnswered + 1}/5</span>
          </div>
        </div>
        
        <button
          onClick={resetGame}
          className="flex items-center space-x-2 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
        >
          <RefreshCw size={20} />
          <span>Restart</span>
        </button>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-gray-200 rounded-full h-3 mb-8">
        <div 
          className="bg-blue-500 h-3 rounded-full transition-all duration-300"
          style={{ width: `${(questionsAnswered / 5) * 100}%` }}
        ></div>
      </div>

      {/* Question */}
      <div className="text-center mb-8">
        <div className="bg-white rounded-3xl p-8 shadow-lg mb-6">
          <h3 className="text-6xl font-bold text-gray-800 mb-4">
            {currentQuestion.num1} {currentQuestion.operator} {currentQuestion.num2} = ?
          </h3>
          <p className="text-xl text-gray-600">Choose the correct answer!</p>
        </div>

        {/* Answer Options */}
        <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
          {currentQuestion.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswerClick(option)}
              disabled={isCorrect !== null}
              className={`p-6 text-2xl font-bold rounded-2xl transition-all duration-200 ${
                selectedAnswer === option
                  ? isCorrect
                    ? 'bg-green-500 text-white shadow-lg scale-105'
                    : 'bg-red-500 text-white shadow-lg scale-105'
                  : selectedAnswer !== null
                    ? option === currentQuestion.answer
                      ? 'bg-green-500 text-white shadow-lg'
                      : 'bg-gray-200 text-gray-400'
                    : 'bg-blue-500 text-white hover:bg-blue-600 hover:scale-105 shadow-md'
              }`}
            >
              {option}
            </button>
          ))}
        </div>

        {/* Feedback */}
        {isCorrect !== null && (
          <div className="mt-6">
            <div className={`inline-flex items-center space-x-2 px-6 py-3 rounded-full ${
              isCorrect ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
            }`}>
              <span className="text-2xl">{isCorrect ? '🎉' : '😅'}</span>
              <span className="font-bold">
                {isCorrect ? 'Correct!' : `Wrong! The answer is ${currentQuestion.answer}`}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Result Modal */}
      {showResult && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-3xl p-8 text-center max-w-md mx-4">
            <div className="text-6xl mb-4">
              {score >= 4 ? '🏆' : score >= 3 ? '🎉' : '👍'}
            </div>
            <h3 className="text-2xl font-bold text-gray-800 mb-2">Level Complete!</h3>
            <p className="text-gray-600 mb-4">You got {score} out of 5 questions correct!</p>
            
            <div className="flex justify-center space-x-1 mb-6">
              {[...Array(3)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-8 h-8 ${i < stars ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
                />
              ))}
            </div>
            
            <div className="flex space-x-4">
              <button
                onClick={resetGame}
                className="flex-1 bg-gray-500 text-white py-3 rounded-lg hover:bg-gray-600 transition-colors"
              >
                Play Again
              </button>
              {level < 8 && score >= 3 && (
                <button
                  onClick={nextLevel}
                  className="flex-1 bg-green-500 text-white py-3 rounded-lg hover:bg-green-600 transition-colors"
                >
                  Next Level
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}