import React, { useState, useEffect } from 'react';
import { Star, RefreshCw } from 'lucide-react';

interface Shape {
  id: string;
  type: 'circle' | 'square' | 'triangle' | 'rectangle' | 'diamond' | 'star';
  color: string;
  size: number;
}

interface Container {
  id: string;
  type: 'circle' | 'square' | 'triangle' | 'rectangle' | 'diamond' | 'star';
  shapes: Shape[];
}

interface ShapeSorterProps {
  gameId: string;
  onProgress: (level: number, stars: number) => void;
}

const shapeTypes = ['circle', 'square', 'triangle', 'rectangle', 'diamond', 'star'];
const colors = ['#ff6b6b', '#4ecdc4', '#45b7d1', '#f9ca24', '#f0932b', '#eb4d4b', '#6c5ce7', '#a29bfe'];

export default function ShapeSorter({ gameId, onProgress }: ShapeSorterProps) {
  const [level, setLevel] = useState(1);
  const [shapes, setShapes] = useState<Shape[]>([]);
  const [containers, setContainers] = useState<Container[]>([]);
  const [draggedShape, setDraggedShape] = useState<Shape | null>(null);
  const [isComplete, setIsComplete] = useState(false);
  const [stars, setStars] = useState(0);
  const [moves, setMoves] = useState(0);

  const generateShapes = () => {
    const numShapeTypes = Math.min(3 + level, 6);
    const shapesPerType = Math.min(2 + level, 4);
    const selectedTypes = shapeTypes.slice(0, numShapeTypes);
    
    const newShapes: Shape[] = [];
    const newContainers: Container[] = [];
    
    selectedTypes.forEach(type => {
      newContainers.push({
        id: type,
        type: type as any,
        shapes: []
      });
      
      for (let i = 0; i < shapesPerType; i++) {
        newShapes.push({
          id: `${type}-${i}`,
          type: type as any,
          color: colors[Math.floor(Math.random() * colors.length)],
          size: 40 + Math.random() * 20
        });
      }
    });
    
    // Shuffle shapes
    for (let i = newShapes.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [newShapes[i], newShapes[j]] = [newShapes[j], newShapes[i]];
    }
    
    setShapes(newShapes);
    setContainers(newContainers);
    setMoves(0);
    setIsComplete(false);
  };

  useEffect(() => {
    generateShapes();
  }, [level]);

  const handleDragStart = (shape: Shape) => {
    setDraggedShape(shape);
  };

  const handleDrop = (containerId: string) => {
    if (!draggedShape) return;
    
    const container = containers.find(c => c.id === containerId);
    if (!container) return;
    
    // Check if shape matches container type
    if (draggedShape.type === container.type) {
      setMoves(moves + 1);
      
      // Move shape to container
      setShapes(prev => prev.filter(s => s.id !== draggedShape.id));
      setContainers(prev => prev.map(c => 
        c.id === containerId 
          ? { ...c, shapes: [...c.shapes, draggedShape] }
          : c
      ));
      
      // Check if all shapes are sorted
      const remainingShapes = shapes.filter(s => s.id !== draggedShape.id);
      if (remainingShapes.length === 0) {
        setIsComplete(true);
        const earnedStars = moves < 5 ? 3 : moves < 10 ? 2 : 1;
        setStars(earnedStars);
        onProgress(level, earnedStars);
      }
    }
    
    setDraggedShape(null);
  };

  const renderShape = (shape: Shape, inContainer = false) => {
    const commonProps = {
      style: { 
        width: shape.size, 
        height: shape.size, 
        backgroundColor: shape.color,
        margin: inContainer ? '2px' : '4px'
      },
      className: inContainer 
        ? 'transition-all duration-200' 
        : 'cursor-move hover:scale-110 transition-all duration-200 shadow-lg'
    };

    switch (shape.type) {
      case 'circle':
        return (
          <div
            key={shape.id}
            {...commonProps}
            className={`${commonProps.className} rounded-full`}
            draggable={!inContainer}
            onDragStart={() => !inContainer && handleDragStart(shape)}
          />
        );
      case 'square':
        return (
          <div
            key={shape.id}
            {...commonProps}
            className={`${commonProps.className} rounded-lg`}
            draggable={!inContainer}
            onDragStart={() => !inContainer && handleDragStart(shape)}
          />
        );
      case 'triangle':
        return (
          <div
            key={shape.id}
            className={inContainer ? 'transition-all duration-200 m-1' : 'cursor-move hover:scale-110 transition-all duration-200 shadow-lg m-1'}
            draggable={!inContainer}
            onDragStart={() => !inContainer && handleDragStart(shape)}
          >
            <div
              style={{
                width: 0,
                height: 0,
                borderLeft: `${shape.size / 2}px solid transparent`,
                borderRight: `${shape.size / 2}px solid transparent`,
                borderBottom: `${shape.size}px solid ${shape.color}`,
              }}
            />
          </div>
        );
      case 'rectangle':
        return (
          <div
            key={shape.id}
            {...commonProps}
            style={{ ...commonProps.style, width: shape.size * 1.5 }}
            className={`${commonProps.className} rounded-lg`}
            draggable={!inContainer}
            onDragStart={() => !inContainer && handleDragStart(shape)}
          />
        );
      case 'diamond':
        return (
          <div
            key={shape.id}
            {...commonProps}
            className={`${commonProps.className} transform rotate-45`}
            draggable={!inContainer}
            onDragStart={() => !inContainer && handleDragStart(shape)}
          />
        );
      case 'star':
        return (
          <div
            key={shape.id}
            className={inContainer ? 'transition-all duration-200 m-1' : 'cursor-move hover:scale-110 transition-all duration-200 shadow-lg m-1'}
            draggable={!inContainer}
            onDragStart={() => !inContainer && handleDragStart(shape)}
          >
            <div
              style={{ 
                fontSize: shape.size * 0.8, 
                color: shape.color,
                filter: 'drop-shadow(2px 2px 4px rgba(0,0,0,0.3))'
              }}
            >
              ⭐
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  const nextLevel = () => {
    if (level < 7) {
      setLevel(level + 1);
    }
  };

  const resetGame = () => {
    generateShapes();
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      {/* Game Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          <h2 className="text-2xl font-bold text-gray-800">Level {level}</h2>
          <span className="text-gray-600">Moves: {moves}</span>
        </div>
        
        <button
          onClick={resetGame}
          className="flex items-center space-x-2 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
        >
          <RefreshCw size={20} />
          <span>Restart</span>
        </button>
      </div>

      {/* Instruction */}
      <div className="text-center mb-8">
        <p className="text-lg text-gray-600">
          Drag and drop shapes into their matching containers!
        </p>
      </div>

      {/* Containers */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-6 mb-8">
        {containers.map(container => (
          <div
            key={container.id}
            className="bg-gray-100 border-2 border-dashed border-gray-300 rounded-xl p-4 min-h-32 flex flex-col items-center"
            onDragOver={(e) => e.preventDefault()}
            onDrop={() => handleDrop(container.id)}
          >
            <div className="text-lg font-bold text-gray-700 mb-2 capitalize">
              {container.type}s
            </div>
            <div className="flex flex-wrap justify-center">
              {container.shapes.map(shape => renderShape(shape, true))}
            </div>
          </div>
        ))}
      </div>

      {/* Shapes to Sort */}
      <div className="bg-white rounded-xl p-6 shadow-lg">
        <h3 className="text-lg font-bold text-gray-800 mb-4 text-center">
          Shapes to Sort ({shapes.length} remaining)
        </h3>
        <div className="flex flex-wrap justify-center gap-2">
          {shapes.map(shape => renderShape(shape))}
        </div>
      </div>

      {/* Success Modal */}
      {isComplete && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-3xl p-8 text-center max-w-md mx-4">
            <div className="text-6xl mb-4">🎯</div>
            <h3 className="text-2xl font-bold text-gray-800 mb-2">Perfect Sorting!</h3>
            <p className="text-gray-600 mb-4">You sorted all shapes in {moves} moves!</p>
            
            <div className="flex justify-center space-x-1 mb-6">
              {[...Array(3)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-8 h-8 ${i < stars ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
                />
              ))}
            </div>
            
            <div className="flex space-x-4">
              <button
                onClick={resetGame}
                className="flex-1 bg-gray-500 text-white py-3 rounded-lg hover:bg-gray-600 transition-colors"
              >
                Play Again
              </button>
              {level < 7 && (
                <button
                  onClick={nextLevel}
                  className="flex-1 bg-green-500 text-white py-3 rounded-lg hover:bg-green-600 transition-colors"
                >
                  Next Level
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}