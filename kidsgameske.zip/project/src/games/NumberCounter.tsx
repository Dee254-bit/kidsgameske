import React, { useState, useEffect } from 'react';
import { Star, RefreshCw } from 'lucide-react';

interface NumberCounterProps {
  gameId: string;
  onProgress: (level: number, stars: number) => void;
}

const emojis = ['🍎', '🌟', '🐛', '🌸', '🎈', '🦋', '🍓', '🌻', '🐝', '🎾'];

interface CountingChallenge {
  items: string[];
  correctAnswer: number;
  options: number[];
}

export default function NumberCounter({ gameId, onProgress }: NumberCounterProps) {
  const [level, setLevel] = useState(1);
  const [challenge, setChallenge] = useState<CountingChallenge | null>(null);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [questionsCompleted, setQuestionsCompleted] = useState(0);
  const [stars, setStars] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [mistakes, setMistakes] = useState(0);

  const generateChallenge = (): CountingChallenge => {
    const maxCount = Math.min(5 + level * 2, 15);
    const correctAnswer = Math.floor(Math.random() * maxCount) + 1;
    const emoji = emojis[Math.floor(Math.random() * emojis.length)];
    
    // Create items array
    const items = Array(correctAnswer).fill(emoji);
    
    // Generate wrong options
    const options = [correctAnswer];
    while (options.length < 4) {
      const wrongAnswer = Math.max(1, correctAnswer + Math.floor(Math.random() * 6) - 3);
      if (!options.includes(wrongAnswer) && wrongAnswer <= maxCount) {
        options.push(wrongAnswer);
      }
    }
    
    // Shuffle options
    for (let i = options.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [options[i], options[j]] = [options[j], options[i]];
    }
    
    return { items, correctAnswer, options };
  };

  useEffect(() => {
    setChallenge(generateChallenge());
  }, [level]);

  const handleAnswerClick = (answer: number) => {
    if (selectedAnswer !== null) return;
    
    setSelectedAnswer(answer);
    const correct = answer === challenge?.correctAnswer;
    setIsCorrect(correct);
    
    if (!correct) {
      setMistakes(mistakes + 1);
    }
    
    setTimeout(() => {
      const newQuestionsCompleted = questionsCompleted + 1;
      setQuestionsCompleted(newQuestionsCompleted);
      
      if (newQuestionsCompleted >= 5) {
        // Level complete
        const earnedStars = mistakes === 0 ? 3 : mistakes <= 1 ? 2 : 1;
        setStars(earnedStars);
        setShowResult(true);
        onProgress(level, earnedStars);
      } else {
        setChallenge(generateChallenge());
        setSelectedAnswer(null);
        setIsCorrect(null);
      }
    }, 1500);
  };

  const nextLevel = () => {
    if (level < 5) {
      setLevel(level + 1);
      resetGame();
    }
  };

  const resetGame = () => {
    setQuestionsCompleted(0);
    setMistakes(0);
    setSelectedAnswer(null);
    setIsCorrect(null);
    setShowResult(false);
    setChallenge(generateChallenge());
  };

  if (!challenge) return <div>Loading...</div>;

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Game Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          <h2 className="text-2xl font-bold text-gray-800">Level {level}</h2>
          <span className="text-gray-600">Question: {questionsCompleted + 1}/5</span>
        </div>
        
        <button
          onClick={resetGame}
          className="flex items-center space-x-2 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
        >
          <RefreshCw size={20} />
          <span>Restart</span>
        </button>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-gray-200 rounded-full h-3 mb-8">
        <div 
          className="bg-blue-500 h-3 rounded-full transition-all duration-300"
          style={{ width: `${(questionsCompleted / 5) * 100}%` }}
        ></div>
      </div>

      {/* Counting Challenge */}
      <div className="text-center mb-8">
        <h3 className="text-2xl font-bold text-gray-800 mb-6">
          Count the items!
        </h3>
        
        {/* Items to Count */}
        <div className="bg-white rounded-3xl p-8 shadow-lg mb-8">
          <div className="flex flex-wrap justify-center gap-4 max-w-3xl mx-auto">
            {challenge.items.map((item, index) => (
              <div
                key={index}
                className="text-4xl md:text-5xl animate-bounce"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                {item}
              </div>
            ))}
          </div>
        </div>

        {/* Answer Options */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-md mx-auto">
          {challenge.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswerClick(option)}
              disabled={selectedAnswer !== null}
              className={`p-6 text-3xl font-bold rounded-2xl transition-all duration-200 ${
                selectedAnswer === option
                  ? isCorrect
                    ? 'bg-green-500 text-white shadow-lg scale-105'
                    : 'bg-red-500 text-white shadow-lg scale-105'
                  : selectedAnswer !== null
                    ? option === challenge.correctAnswer
                      ? 'bg-green-500 text-white shadow-lg'
                      : 'bg-gray-200 text-gray-400'
                    : 'bg-blue-500 text-white hover:bg-blue-600 hover:scale-105 shadow-md'
              }`}
            >
              {option}
            </button>
          ))}
        </div>

        {/* Feedback */}
        {isCorrect !== null && (
          <div className="mt-6">
            <div className={`inline-flex items-center space-x-2 px-6 py-3 rounded-full ${
              isCorrect ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
            }`}>
              <span className="text-2xl">{isCorrect ? '🎉' : '🤔'}</span>
              <span className="font-bold">
                {isCorrect ? 'Correct! Great counting!' : `Try again! The answer is ${challenge.correctAnswer}`}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Result Modal */}
      {showResult && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-3xl p-8 text-center max-w-md mx-4">
            <div className="text-6xl mb-4">🔢</div>
            <h3 className="text-2xl font-bold text-gray-800 mb-2">Level Complete!</h3>
            <p className="text-gray-600 mb-4">You're a counting champion!</p>
            
            <div className="flex justify-center space-x-1 mb-6">
              {[...Array(3)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-8 h-8 ${i < stars ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
                />
              ))}
            </div>
            
            <div className="flex space-x-4">
              <button
                onClick={resetGame}
                className="flex-1 bg-gray-500 text-white py-3 rounded-lg hover:bg-gray-600 transition-colors"
              >
                Play Again
              </button>
              {level < 5 && (
                <button
                  onClick={nextLevel}
                  className="flex-1 bg-green-500 text-white py-3 rounded-lg hover:bg-green-600 transition-colors"
                >
                  Next Level
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}