import React, { useState, useEffect } from 'react';
import { Star, RefreshCw, Volume2 } from 'lucide-react';

interface AnimalSoundsProps {
  gameId: string;
  onProgress: (level: number, stars: number) => void;
}

const animals = [
  { name: 'Dog', emoji: '🐶', sound: 'Woof! Woof!' },
  { name: 'Cat', emoji: '🐱', sound: 'Meow! Meow!' },
  { name: 'Cow', emoji: '🐮', sound: 'Moo! Moo!' },
  { name: 'Duck', emoji: '🦆', sound: 'Quack! Quack!' },
  { name: 'Pig', emoji: '🐷', sound: 'Oink! Oink!' },
  { name: 'Sheep', emoji: '🐑', sound: 'Baa! Baa!' },
  { name: 'Horse', emoji: '🐴', sound: 'Neigh! Neigh!' },
  { name: 'Rooster', emoji: '🐓', sound: 'Cock-a-doodle-doo!' },
  { name: 'Lion', emoji: '🦁', sound: 'Roar! Roar!' },
  { name: 'Elephant', emoji: '🐘', sound: 'Trumpet! Trumpet!' }
];

export default function AnimalSounds({ gameId, onProgress }: AnimalSoundsProps) {
  const [level, setLevel] = useState(1);
  const [currentAnimal, setCurrentAnimal] = useState(animals[0]);
  const [options, setOptions] = useState<typeof animals>([]);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [questionsCompleted, setQuestionsCompleted] = useState(0);
  const [stars, setStars] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [mistakes, setMistakes] = useState(0);
  const [showSound, setShowSound] = useState(false);

  const generateQuestion = () => {
    const numAnimals = Math.min(3 + level, 6);
    const availableAnimals = animals.slice(0, numAnimals + 2);
    
    // Select current animal
    const animal = availableAnimals[Math.floor(Math.random() * availableAnimals.length)];
    setCurrentAnimal(animal);
    
    // Generate options (3 wrong + 1 correct)
    const wrongOptions = availableAnimals
      .filter(a => a.name !== animal.name)
      .sort(() => Math.random() - 0.5)
      .slice(0, 3);
    
    const allOptions = [...wrongOptions, animal].sort(() => Math.random() - 0.5);
    setOptions(allOptions);
    
    setSelectedAnswer(null);
    setIsCorrect(null);
    setShowSound(false);
  };

  useEffect(() => {
    generateQuestion();
  }, [level]);

  const handleAnswerClick = (animalName: string) => {
    if (selectedAnswer !== null) return;
    
    setSelectedAnswer(animalName);
    const correct = animalName === currentAnimal.name;
    setIsCorrect(correct);
    
    if (!correct) {
      setMistakes(mistakes + 1);
    }
    
    setTimeout(() => {
      const newQuestionsCompleted = questionsCompleted + 1;
      setQuestionsCompleted(newQuestionsCompleted);
      
      if (newQuestionsCompleted >= 4) {
        // Level complete
        const earnedStars = mistakes === 0 ? 3 : mistakes <= 1 ? 2 : 1;
        setStars(earnedStars);
        setShowResult(true);
        onProgress(level, earnedStars);
      } else {
        generateQuestion();
      }
    }, 1500);
  };

  const playSound = () => {
    setShowSound(true);
    setTimeout(() => setShowSound(false), 2000);
  };

  const nextLevel = () => {
    if (level < 4) {
      setLevel(level + 1);
      resetGame();
    }
  };

  const resetGame = () => {
    setQuestionsCompleted(0);
    setMistakes(0);
    setSelectedAnswer(null);
    setIsCorrect(null);
    setShowResult(false);
    generateQuestion();
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Game Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          <h2 className="text-2xl font-bold text-gray-800">Level {level}</h2>
          <span className="text-gray-600">Question: {questionsCompleted + 1}/4</span>
        </div>
        
        <button
          onClick={resetGame}
          className="flex items-center space-x-2 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
        >
          <RefreshCw size={20} />
          <span>Restart</span>
        </button>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-gray-200 rounded-full h-3 mb-8">
        <div 
          className="bg-blue-500 h-3 rounded-full transition-all duration-300"
          style={{ width: `${(questionsCompleted / 4) * 100}%` }}
        ></div>
      </div>

      {/* Question */}
      <div className="text-center mb-8">
        <h3 className="text-2xl font-bold text-gray-800 mb-6">
          Which animal makes this sound?
        </h3>
        
        {/* Sound Display */}
        <div className="bg-white rounded-3xl p-8 shadow-lg mb-8">
          <div className="text-8xl mb-4">{currentAnimal.emoji}</div>
          <button
            onClick={playSound}
            className="flex items-center space-x-2 bg-green-500 text-white px-6 py-3 rounded-full hover:bg-green-600 transition-colors mx-auto mb-4"
          >
            <Volume2 size={24} />
            <span>Play Sound</span>
          </button>
          
          {showSound && (
            <div className="bg-green-100 border-2 border-green-300 rounded-lg p-4 animate-pulse">
              <p className="text-2xl font-bold text-green-800">{currentAnimal.sound}</p>
            </div>
          )}
        </div>

        {/* Answer Options */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto">
          {options.map((animal, index) => (
            <button
              key={index}
              onClick={() => handleAnswerClick(animal.name)}
              disabled={selectedAnswer !== null}
              className={`p-6 rounded-2xl transition-all duration-200 ${
                selectedAnswer === animal.name
                  ? isCorrect
                    ? 'bg-green-500 text-white shadow-lg scale-105'
                    : 'bg-red-500 text-white shadow-lg scale-105'
                  : selectedAnswer !== null
                    ? animal.name === currentAnimal.name
                      ? 'bg-green-500 text-white shadow-lg'
                      : 'bg-gray-200 text-gray-400'
                    : 'bg-blue-500 text-white hover:bg-blue-600 hover:scale-105 shadow-md'
              }`}
            >
              <div className="text-4xl mb-2">{animal.emoji}</div>
              <div className="font-bold">{animal.name}</div>
            </button>
          ))}
        </div>

        {/* Feedback */}
        {isCorrect !== null && (
          <div className="mt-6">
            <div className={`inline-flex items-center space-x-2 px-6 py-3 rounded-full ${
              isCorrect ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
            }`}>
              <span className="text-2xl">{isCorrect ? '🎉' : '🤔'}</span>
              <span className="font-bold">
                {isCorrect ? 'Correct! Great listening!' : `Try again! That was a ${currentAnimal.name}!`}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Result Modal */}
      {showResult && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-3xl p-8 text-center max-w-md mx-4">
            <div className="text-6xl mb-4">🐾</div>
            <h3 className="text-2xl font-bold text-gray-800 mb-2">Level Complete!</h3>
            <p className="text-gray-600 mb-4">You know your animal sounds!</p>
            
            <div className="flex justify-center space-x-1 mb-6">
              {[...Array(3)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-8 h-8 ${i < stars ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
                />
              ))}
            </div>
            
            <div className="flex space-x-4">
              <button
                onClick={resetGame}
                className="flex-1 bg-gray-500 text-white py-3 rounded-lg hover:bg-gray-600 transition-colors"
              >
                Play Again
              </button>
              {level < 4 && (
                <button
                  onClick={nextLevel}
                  className="flex-1 bg-green-500 text-white py-3 rounded-lg hover:bg-green-600 transition-colors"
                >
                  Next Level
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}