import React, { useState, useEffect } from 'react';
import { Star, RefreshCw, Palette } from 'lucide-react';

interface ColorMixerProps {
  gameId: string;
  onProgress: (level: number, stars: number) => void;
}

const colorMixes = {
  1: [
    { colors: ['red', 'yellow'], result: 'orange', name: 'Orange' },
    { colors: ['blue', 'yellow'], result: 'green', name: 'Green' },
    { colors: ['red', 'blue'], result: 'purple', name: 'Purple' }
  ],
  2: [
    { colors: ['red', 'white'], result: 'pink', name: 'Pink' },
    { colors: ['black', 'white'], result: 'gray', name: 'Gray' },
    { colors: ['green', 'yellow'], result: 'lime', name: 'Lime' }
  ],
  3: [
    { colors: ['orange', 'red'], result: 'darkorange', name: 'Dark Orange' },
    { colors: ['purple', 'blue'], result: 'indigo', name: 'Indigo' },
    { colors: ['green', 'blue'], result: 'teal', name: 'Teal' }
  ],
  4: [
    { colors: ['brown', 'yellow'], result: 'gold', name: 'Gold' },
    { colors: ['pink', 'red'], result: 'crimson', name: 'Crimson' },
    { colors: ['gray', 'blue'], result: 'slate', name: 'Slate' }
  ]
};

const colorPalette = {
  red: '#ff0000',
  blue: '#0000ff',
  yellow: '#ffff00',
  green: '#00ff00',
  purple: '#800080',
  orange: '#ffa500',
  pink: '#ffc0cb',
  white: '#ffffff',
  black: '#000000',
  gray: '#808080',
  lime: '#00ff00',
  darkorange: '#ff8c00',
  indigo: '#4b0082',
  teal: '#008080',
  brown: '#a52a2a',
  gold: '#ffd700',
  crimson: '#dc143c',
  slate: '#708090'
};

export default function ColorMixer({ gameId, onProgress }: ColorMixerProps) {
  const [level, setLevel] = useState(1);
  const [currentMix, setCurrentMix] = useState(colorMixes[1][0]);
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [mixesCompleted, setMixesCompleted] = useState(0);
  const [stars, setStars] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [attempts, setAttempts] = useState(0);

  const generateMix = () => {
    const mixes = colorMixes[level as keyof typeof colorMixes];
    const mix = mixes[Math.floor(Math.random() * mixes.length)];
    setCurrentMix(mix);
    setSelectedColors([]);
    setIsCorrect(null);
    setAttempts(0);
  };

  useEffect(() => {
    generateMix();
  }, [level]);

  const handleColorClick = (color: string) => {
    if (selectedColors.includes(color)) {
      setSelectedColors(selectedColors.filter(c => c !== color));
    } else if (selectedColors.length < 2) {
      setSelectedColors([...selectedColors, color]);
    }
  };

  const mixColors = () => {
    if (selectedColors.length !== 2) return;
    
    setAttempts(attempts + 1);
    const sortedSelected = [...selectedColors].sort();
    const sortedRequired = [...currentMix.colors].sort();
    
    const correct = sortedSelected.every((color, index) => color === sortedRequired[index]);
    setIsCorrect(correct);
    
    if (correct) {
      const newMixesCompleted = mixesCompleted + 1;
      setMixesCompleted(newMixesCompleted);
      
      setTimeout(() => {
        if (newMixesCompleted >= 3) {
          // Level complete
          const earnedStars = attempts === 0 ? 3 : attempts <= 2 ? 2 : 1;
          setStars(earnedStars);
          setShowResult(true);
          onProgress(level, earnedStars);
        } else {
          generateMix();
        }
      }, 2000);
    } else {
      setTimeout(() => {
        setIsCorrect(null);
        setSelectedColors([]);
      }, 1500);
    }
  };

  const getMixedColor = () => {
    if (selectedColors.length === 2) {
      const sortedSelected = [...selectedColors].sort();
      const sortedRequired = [...currentMix.colors].sort();
      
      if (sortedSelected.every((color, index) => color === sortedRequired[index])) {
        return colorPalette[currentMix.result as keyof typeof colorPalette];
      }
    }
    
    // Default mixed color for wrong combinations
    return '#999999';
  };

  const nextLevel = () => {
    if (level < 4) {
      setLevel(level + 1);
      resetGame();
    }
  };

  const resetGame = () => {
    setMixesCompleted(0);
    setShowResult(false);
    generateMix();
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Game Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          <h2 className="text-2xl font-bold text-gray-800">Level {level}</h2>
          <span className="text-gray-600">Mixes: {mixesCompleted}/3</span>
        </div>
        
        <button
          onClick={resetGame}
          className="flex items-center space-x-2 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
        >
          <RefreshCw size={20} />
          <span>Restart</span>
        </button>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-gray-200 rounded-full h-3 mb-8">
        <div 
          className="bg-blue-500 h-3 rounded-full transition-all duration-300"
          style={{ width: `${(mixesCompleted / 3) * 100}%` }}
        ></div>
      </div>

      {/* Challenge */}
      <div className="text-center mb-8">
        <h3 className="text-2xl font-bold text-gray-800 mb-4">
          Mix colors to make: <span className="text-3xl">{currentMix.name}</span>
        </h3>
        
        {/* Target Color */}
        <div className="flex justify-center mb-8">
          <div 
            className="w-32 h-32 rounded-full border-4 border-gray-300 shadow-lg"
            style={{ backgroundColor: colorPalette[currentMix.result as keyof typeof colorPalette] }}
          ></div>
        </div>

        {/* Mixing Area */}
        <div className="flex justify-center items-center space-x-4 mb-8">
          <div className="flex space-x-2">
            {[0, 1].map(index => (
              <div
                key={index}
                className="w-20 h-20 rounded-full border-4 border-dashed border-gray-300 flex items-center justify-center"
                style={{ 
                  backgroundColor: selectedColors[index] ? colorPalette[selectedColors[index] as keyof typeof colorPalette] : 'transparent',
                  borderColor: selectedColors[index] ? colorPalette[selectedColors[index] as keyof typeof colorPalette] : '#d1d5db'
                }}
              >
                {!selectedColors[index] && (
                  <span className="text-gray-400 text-sm">Color {index + 1}</span>
                )}
              </div>
            ))}
          </div>
          
          <div className="text-4xl font-bold text-gray-600">=</div>
          
          <div 
            className={`w-24 h-24 rounded-full border-4 border-gray-300 transition-all duration-500 ${
              selectedColors.length === 2 ? 'shadow-lg scale-110' : ''
            }`}
            style={{ 
              backgroundColor: selectedColors.length === 2 ? getMixedColor() : '#f3f4f6'
            }}
          ></div>
        </div>

        {/* Color Palette */}
        <div className="grid grid-cols-3 md:grid-cols-6 gap-4 max-w-2xl mx-auto mb-8">
          {Object.entries(colorPalette).slice(0, level + 5).map(([colorName, colorValue]) => (
            <button
              key={colorName}
              onClick={() => handleColorClick(colorName)}
              className={`w-16 h-16 rounded-full border-4 transition-all duration-200 ${
                selectedColors.includes(colorName)
                  ? 'border-gray-800 scale-110 shadow-lg'
                  : 'border-gray-300 hover:border-gray-500 hover:scale-105'
              }`}
              style={{ backgroundColor: colorValue }}
              title={colorName}
            />
          ))}
        </div>

        {/* Mix Button */}
        <button
          onClick={mixColors}
          disabled={selectedColors.length !== 2}
          className={`flex items-center space-x-2 px-8 py-4 rounded-full text-white font-bold text-lg transition-all duration-200 ${
            selectedColors.length === 2
              ? 'bg-purple-500 hover:bg-purple-600 shadow-lg hover:scale-105'
              : 'bg-gray-400 cursor-not-allowed'
          }`}
        >
          <Palette size={24} />
          <span>Mix Colors!</span>
        </button>

        {/* Feedback */}
        {isCorrect !== null && (
          <div className="mt-6">
            <div className={`inline-flex items-center space-x-2 px-6 py-3 rounded-full ${
              isCorrect ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
            }`}>
              <span className="text-2xl">{isCorrect ? '🎨' : '😅'}</span>
              <span className="font-bold">
                {isCorrect ? 'Perfect! You made the right color!' : 'Try a different combination!'}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Result Modal */}
      {showResult && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-3xl p-8 text-center max-w-md mx-4">
            <div className="text-6xl mb-4">🎨</div>
            <h3 className="text-2xl font-bold text-gray-800 mb-2">Level Complete!</h3>
            <p className="text-gray-600 mb-4">You're a color mixing master!</p>
            
            <div className="flex justify-center space-x-1 mb-6">
              {[...Array(3)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-8 h-8 ${i < stars ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
                />
              ))}
            </div>
            
            <div className="flex space-x-4">
              <button
                onClick={resetGame}
                className="flex-1 bg-gray-500 text-white py-3 rounded-lg hover:bg-gray-600 transition-colors"
              >
                Play Again
              </button>
              {level < 4 && (
                <button
                  onClick={nextLevel}
                  className="flex-1 bg-green-500 text-white py-3 rounded-lg hover:bg-green-600 transition-colors"
                >
                  Next Level
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}