import React, { useState, useEffect } from 'react';
import { Star, RefreshCw } from 'lucide-react';

interface Card {
  id: number;
  emoji: string;
  isFlipped: boolean;
  isMatched: boolean;
}

interface MemoryMatchProps {
  gameId: string;
  onProgress: (level: number, stars: number) => void;
}

const emojis = ['🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼', '🐨', '🐯', '🦁', '🐮'];

export default function MemoryMatch({ gameId, onProgress }: MemoryMatchProps) {
  const [level, setLevel] = useState(1);
  const [cards, setCards] = useState<Card[]>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [isWon, setIsWon] = useState(false);
  const [stars, setStars] = useState(0);

  const initializeGame = () => {
    const cardCount = Math.min(4 + level * 2, 12);
    const gameEmojis = emojis.slice(0, cardCount / 2);
    const duplicatedEmojis = [...gameEmojis, ...gameEmojis];
    
    const shuffledCards: Card[] = duplicatedEmojis
      .sort(() => Math.random() - 0.5)
      .map((emoji, index) => ({
        id: index,
        emoji,
        isFlipped: false,
        isMatched: false
      }));
    
    setCards(shuffledCards);
    setFlippedCards([]);
    setMoves(0);
    setIsWon(false);
    setStars(0);
  };

  useEffect(() => {
    initializeGame();
  }, [level]);

  const handleCardClick = (cardId: number) => {
    if (flippedCards.length === 2) return;
    if (flippedCards.includes(cardId)) return;
    if (cards[cardId].isMatched) return;

    const newFlippedCards = [...flippedCards, cardId];
    setCards(prev => prev.map(card => 
      card.id === cardId ? { ...card, isFlipped: true } : card
    ));

    if (newFlippedCards.length === 2) {
      setMoves(prev => prev + 1);
      
      const [first, second] = newFlippedCards;
      if (cards[first].emoji === cards[second].emoji) {
        // Match found
        setTimeout(() => {
          setCards(prev => prev.map(card => 
            card.id === first || card.id === second 
              ? { ...card, isMatched: true } 
              : card
          ));
          setFlippedCards([]);
          
          // Check if game is won
          const updatedCards = cards.map(card => 
            card.id === first || card.id === second 
              ? { ...card, isMatched: true } 
              : card
          );
          
          if (updatedCards.every(card => card.isMatched)) {
            setIsWon(true);
            const earnedStars = moves < 8 ? 3 : moves < 12 ? 2 : 1;
            setStars(earnedStars);
            onProgress(level, earnedStars);
          }
        }, 1000);
      } else {
        // No match
        setTimeout(() => {
          setCards(prev => prev.map(card => 
            card.id === first || card.id === second 
              ? { ...card, isFlipped: false } 
              : card
          ));
          setFlippedCards([]);
        }, 1000);
      }
    } else {
      setFlippedCards(newFlippedCards);
    }
  };

  const nextLevel = () => {
    if (level < 5) {
      setLevel(level + 1);
    } else {
      // Game completed!
      alert('Congratulations! You completed all levels!');
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Game Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <h2 className="text-2xl font-bold text-gray-800">Level {level}</h2>
          <div className="flex items-center space-x-2">
            <span className="text-gray-600">Moves: {moves}</span>
          </div>
        </div>
        
        <button
          onClick={initializeGame}
          className="flex items-center space-x-2 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
        >
          <RefreshCw size={20} />
          <span>Restart</span>
        </button>
      </div>

      {/* Game Board */}
      <div className={`grid gap-4 mb-6 ${
        cards.length <= 8 ? 'grid-cols-4' : 
        cards.length <= 12 ? 'grid-cols-4 md:grid-cols-6' : 
        'grid-cols-4 md:grid-cols-6 lg:grid-cols-8'
      }`}>
        {cards.map(card => (
          <div
            key={card.id}
            onClick={() => handleCardClick(card.id)}
            className={`aspect-square rounded-xl cursor-pointer transform transition-all duration-300 ${
              card.isFlipped || card.isMatched
                ? 'bg-white shadow-lg scale-105'
                : 'bg-blue-500 hover:bg-blue-600 hover:scale-105'
            } ${card.isMatched ? 'ring-4 ring-green-400' : ''}`}
          >
            <div className="w-full h-full flex items-center justify-center text-4xl">
              {card.isFlipped || card.isMatched ? card.emoji : '?'}
            </div>
          </div>
        ))}
      </div>

      {/* Win Modal */}
      {isWon && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-3xl p-8 text-center max-w-md mx-4">
            <div className="text-6xl mb-4">🎉</div>
            <h3 className="text-2xl font-bold text-gray-800 mb-2">Level Complete!</h3>
            <p className="text-gray-600 mb-4">You finished in {moves} moves!</p>
            
            <div className="flex justify-center space-x-1 mb-6">
              {[...Array(3)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-8 h-8 ${i < stars ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
                />
              ))}
            </div>
            
            <div className="flex space-x-4">
              <button
                onClick={initializeGame}
                className="flex-1 bg-gray-500 text-white py-3 rounded-lg hover:bg-gray-600 transition-colors"
              >
                Play Again
              </button>
              {level < 5 && (
                <button
                  onClick={nextLevel}
                  className="flex-1 bg-green-500 text-white py-3 rounded-lg hover:bg-green-600 transition-colors"
                >
                  Next Level
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}