import React from 'react';
import { Star, Clock, Wrench } from 'lucide-react';

interface ComingSoonProps {
  gameId: string;
  onProgress: (level: number, stars: number) => void;
}

export default function ComingSoon({ gameId, onProgress }: ComingSoonProps) {
  return (
    <div className="max-w-4xl mx-auto p-6 text-center">
      <div className="bg-white rounded-3xl p-12 shadow-lg">
        <div className="text-8xl mb-6">🚧</div>
        
        <h2 className="text-4xl font-bold text-gray-800 mb-4">
          Coming Soon!
        </h2>
        
        <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
          We're working hard to bring you this amazing game! Our team of developers 
          is crafting an incredible experience that will be both fun and educational.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-blue-50 rounded-xl p-6">
            <div className="text-3xl mb-3">🎮</div>
            <h3 className="font-bold text-gray-800 mb-2">Interactive Gameplay</h3>
            <p className="text-gray-600 text-sm">
              Engaging mechanics designed specifically for young learners
            </p>
          </div>
          
          <div className="bg-green-50 rounded-xl p-6">
            <div className="text-3xl mb-3">🏆</div>
            <h3 className="font-bold text-gray-800 mb-2">Progressive Levels</h3>
            <p className="text-gray-600 text-sm">
              Multiple difficulty levels that grow with your skills
            </p>
          </div>
          
          <div className="bg-purple-50 rounded-xl p-6">
            <div className="text-3xl mb-3">🎨</div>
            <h3 className="font-bold text-gray-800 mb-2">Beautiful Graphics</h3>
            <p className="text-gray-600 text-sm">
              Colorful, child-friendly visuals that spark imagination
            </p>
          </div>
        </div>
        
        <div className="bg-yellow-50 border-2 border-yellow-200 rounded-xl p-6 mb-8">
          <div className="flex items-center justify-center space-x-2 mb-3">
            <Clock className="text-yellow-600" size={24} />
            <span className="font-bold text-yellow-800">Development Status</span>
          </div>
          <div className="w-full bg-yellow-200 rounded-full h-4 mb-3">
            <div className="bg-yellow-500 h-4 rounded-full animate-pulse" style={{ width: '65%' }}></div>
          </div>
          <p className="text-yellow-800 font-medium">65% Complete</p>
        </div>
        
        <div className="flex items-center justify-center space-x-2 text-gray-500">
          <Wrench size={20} />
          <span>Check back soon for updates!</span>
        </div>
        
        <div className="mt-8 flex justify-center space-x-1">
          {[...Array(3)].map((_, i) => (
            <Star
              key={i}
              className="w-8 h-8 text-gray-300"
            />
          ))}
        </div>
      </div>
    </div>
  );
}